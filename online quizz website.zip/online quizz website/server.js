const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors()); // allow frontend to talk to backend
app.use(bodyParser.json());

// Quiz Questions (we can later move these to a database)
const questions = [
  {
    num: 1,
    questions: "What does html stands for?",
    answer: "C) Hyper Text Markup Language",
    options: [
      "A) Hyper Type Multi Language",
      "B) Hyper Text Multiple Language",
      "C) Hyper Text Markup Language",
      "D) Home Text Multi Language",
    ],
  },
  {
    num: 2,
    questions: "What language is used for styling web pages?",
    answer: "B) CSS ",
    options: ["A) HTML", "B) CSS ", "C) JavaScript", "D) SQL"],
  },
  {
    num: 3,
    questions: "What does SQL stand for?",
    answer: "B) Structured Query Language",
    options: [
      "A) Simple Query Language",
      "B) Structured Query Language",
      "C) Standard Question Language",
      "D) Server Query Language",
    ],
  },
  {
    num: 4,
    questions: "Which of these is a NoSQL database?",
    answer: "C) MongoDB",
    options: ["A) MySQL", "B) PostgreSQL", "C) MongoDB", "D) Oracle"],
  },
  {
    num: 5,
    questions: "What is the main function of the backend in web development?",
    answer: "C) Manage database and server logic",
    options: [
      "A) Design layouts",
      "B) Handle user input",
      "C) Manage database and server logic",
      "D) Create animations",
    ],
  },
];

// API route to get questions
app.get("/api/questions", (req, res) => {
  res.json(questions);
});

// API route to submit score
app.post("/api/submit", (req, res) => {
  const { name, score } = req.body;
  console.log(`Received score: ${name} scored ${score}`);
  res.json({ message: "Score submitted successfully!" });
});

// Start server
app.listen(PORT, () =>
  console.log(`✅ Server running at http://localhost:${PORT}`)
);
