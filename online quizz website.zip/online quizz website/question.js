let questions = [
    {
        num: 1,
        questions: "What does html stands for?",
        answer: "C) Hyper Text Markup Language",
        options: [
            "A) Hyper Type Multi Language",
            "B) Hyper Text Multiple Language",
            "C) Hyper Text Markup Language",
            "D) Home Text Multi Language"
        ]
    },
    {
        num: 2,
        questions: "What language is used for styling web pages?",
        answer: "B) CSS ",
        options: [
            "A) HTML",
            "B) CSS ",
            "C) JavaScript",
            "D) SQL"
        ]
    },
    {
        num: 3,
        questions: "What does SQL stand for?",
        answer: "B) Structured Query Language",
        options: [
            "A) Simple Query Language",
            "B) Structured Query Language",
            "C) Standard Question Language",
            "D) Server Query Language"
        ]
    },
    {
        num: 4,
        questions: "Which of these is a NoSQL database?",
        answer: "C) MongoDB",
        options: [
            "A) MySQL",
            "B) PostgreSQL",
            "C) MongoDB",
            "D) Oracle"
        ]
    },
    {
        num: 5,
        questions: "What is the main function of the backend in web development?",
        answer: "C) Manage database and server logic",
        options: [
            "A) Design layouts",
            "B) Handle user input",
            "C) Manage database and server logic",
            "D) Create animations"
        ]
    }
]



